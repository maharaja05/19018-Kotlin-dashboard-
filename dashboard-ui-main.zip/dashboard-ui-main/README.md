### Live Demo

[Githr Dashboard - Vercel](https://githr.vercel.app/)

### Preview

![Githr - Dashboard UI](public/preview.png)

## Star History

<a href="https://star-history.com/#kartikk-k/dashboard-ui&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=kartikk-k/dashboard-ui&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=kartikk-k/dashboard-ui&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=kartikk-k/dashboard-ui&type=Date" />
 </picture>
</a>
